<?php

$Servidor = "localhost";
$Usuario = "root";
$password = "";
$baseDeDatos = "edgarimport";

$conexion = mysqli_connect($Servidor, $Usuario, $password, $baseDeDatos);

if(!$con){
    echo "conexion fallida";
}

?>