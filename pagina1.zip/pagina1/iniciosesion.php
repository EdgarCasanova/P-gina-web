<?php

// Configuración de la base de datos
$Servidor = "localhost";
$Usuario = "root";
$password = "";
$baseDeDatos = "edgarimport";

// Conexión a la base de datos
$conn = new mysqli($Servidor, $Usuario, $password, $baseDeDatos);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <!-- Formulario de inicio de sesión -->
<div class="contenedor-formulario">
    <h1>Iniciar sesión</h1>
    <form method="post">
    <form action="iniciosesion.php" method="post" >
      <label for="email">email:</label>
      <input type="email"  name="email" placeholder="email">
      <label for="password">password:</label>
      <input type="password" name="password" placeholder="password">
      <button  type="submit"> Iniciar sesión</button>
      <p>¿No tienes cuenta? <a href="registro.php" id="registro-link">Regístrate</a></p>
    </form>
    </form>
  </div>
  

 
</body>
</html>
<?php

// Verificar si la conexión es exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recuperar los datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Consulta para verificar si el usuario existe y la contraseña es correcta
$query = "SELECT * FROM usuarios WHERE email = '$email' AND password = '$password'";
$resultado = $conn->query($query);

// Verificar si el usuario existe y la contraseña es correcta
if ($resultado->num_rows > 0) {
    // Iniciar sesión
    session_start();
    $_SESSION['email'] = $email;
    header('Location: Untitled-1.html'); // Redireccionar a la página principal
} else {
    // Mostrar mensaje de error
    echo "Usuario o contraseña incorrectos";
}

     

// Cerrar la conexión a la base de datos
$conn->close();
?>