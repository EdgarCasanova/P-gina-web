<?php
// Configuración de la base de datos
$Servidor = "localhost";
$Usuario = "root";
$password = "";
$baseDeDatos = "edgarimport";

// Crear conexión con la base de datos
$enlace = mysqli_connect ($Servidor, $Usuario, $password, $baseDeDatos);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/registro.css">
    <title>registro</title>
</head>

<body>
    <!-- Formulario de registro -->
<div class="contenedor-formulario" id="registro-form">
    <h1>Registro</h1>
    <form method="post">
    <form action="#" name= "edgarimport" method="post">

      <label for="nombre">nombre:</label>
      <input type="text" name="nombre" placeholder="nombre">
      <label for="apellido">apellido:</label>
      <input type="text"  name="apellido" placeholder="apellido">
      <label for="email">email :</label>
      <input type="email" name="email" placeholder="email">
      <label for="password">password:</label>
      <input type="password"  name="password" placeholder="password">
      <button type="submit" name= "registro"> Registro</button>
      <p>¿Ya tienes cuenta? <a href="index.html" >Iniciar sesión</a></p>
      
    </form>
    </form>
  </div>
</body>
</html>

<?php

// Procesar formulario de registro
   if (isset($_POST['registro'])) {

        $nombre = $_POST ['nombre'];
        $apellido = $_POST ['apellido'];
        $email = $_POST ['email'];
        $password = $_POST ['password'];
    

  

    // Insertar usuario en la base de datos
    $insertarusuarios = "INSERT INTO usuarios VALUES('$nombre','$apellido','$email','$password','')";


    $ejecutarinsertar = mysqli_query ($enlace,$insertarusuarios);
}
if($ejecutarinsertar){
  echo'
  <script>
  alert("Usuario registrado con exitosamente");
  window.location = "iniciosesion.php";
  </script>
  
  ';
}
   

?>